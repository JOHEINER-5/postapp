package com.johe.medina.project.Fragments.Principal.UploadAudio;

public interface ComunicadorAudio {
    void actualizar();
}
