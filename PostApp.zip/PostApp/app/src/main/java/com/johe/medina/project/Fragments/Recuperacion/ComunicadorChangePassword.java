package com.johe.medina.project.Fragments.Recuperacion;

import android.support.v4.app.Fragment;


public interface ComunicadorChangePassword {
    void changeFragment(Fragment fragment);
    void finalizar();
    void hideKeyboard();
}
