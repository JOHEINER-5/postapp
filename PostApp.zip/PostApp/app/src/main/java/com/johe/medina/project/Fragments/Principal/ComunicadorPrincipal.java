package com.johe.medina.project.Fragments.Principal;


public interface ComunicadorPrincipal {
    void actualizarPost();
    void finalizar();
    void hideKeyboard();
    void actualizarFragmentAudio();
}
